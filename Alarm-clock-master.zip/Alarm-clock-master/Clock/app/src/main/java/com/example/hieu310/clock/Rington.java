package com.example.hieu310.clock;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;
import android.provider.MediaStore;
import android.support.annotation.Nullable;

/**
 * Created by hieu310 on 11/8/2016.
 */

public class Rington extends Service{

    MediaPlayer mediaPlayer;
    boolean isRunning;
    int state;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Uri uri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        String extra = intent.getExtras().getString("extra");

        assert  extra != null;
        switch (extra){
            case "ON":
                startId = 1;
                break;
            case "OFF":
                startId = 0;
                break;
            default:
                startId = 0;
                break;
        }



        if (!this.isRunning && startId == 1){
            mediaPlayer = MediaPlayer.create(this, uri);
            mediaPlayer.start();
            this.isRunning = true;
            startId = 0;
        }else if (this.isRunning && startId == 0){
            mediaPlayer.stop();
            mediaPlayer.reset();
            this.isRunning = false;
            startId = 0;
        }else if(!this.isRunning && startId == 0){
            this.isRunning = false;
            startId = 0;
        }else if(this.isRunning && startId == 1) {
            this.isRunning = true;
            startId = 1;
        }
        return START_NOT_STICKY;
    }
}
