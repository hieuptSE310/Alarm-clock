package com.example.hieu310.clock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by hieu310 on 11/8/2016.
 */

public class BroastcastRec extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        String ex = intent.getExtras().getString("extra");
        Intent service_intent = new Intent(context, Rington.class);
        service_intent.putExtra("extra", ex);
        context.startService(service_intent);
    }
}
